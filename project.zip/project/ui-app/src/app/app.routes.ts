import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { FileListComponent } from './file-list/file-list.component';
import { RegisterComponent } from './register/register.component';
import { UploadComponent } from './upload/upload.component';

export const routes: Routes = [
    { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'upload', component: UploadComponent },
  { path: 'files', component: FileListComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];
