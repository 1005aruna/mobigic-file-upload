import { Component } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule,FormsModule,HttpClientModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})

export class RegisterComponent {
  username: string = '';
  password: string = '';

  constructor(public http: HttpClient, public router:Router) {}
  register() {
    this.http.post('http://localhost:5000/api/register', { username: this.username, password: this.password })
      .subscribe(() => this.router.navigate(['/login']));
  }
}
