import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http: HttpClient) { }

  login(username:string, password:string):Observable<any>{
     return this.http.post<{ token: string }>('http://localhost:5000/api/login', { username, password })
      // .subscribe(response => {
      //   localStorage.setItem('token', response.token);
      //   this.router.navigate(['/upload']);
      // });
  }
}
