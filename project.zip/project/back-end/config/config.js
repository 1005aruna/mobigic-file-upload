module.exports = {
    mongoURI: 'mongodb://localhost:27017/fileuploadapp',
    jwtSecret: 'jwt', 
    uploadPath: 'uploads/'
};
