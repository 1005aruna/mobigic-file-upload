import { Component } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule,FormsModule,HttpClientModule],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private http: HttpClient, private router:Router) {}

  login() {
    this.http.post<{ token: string }>('http://localhost:5000/api/login', { username: this.username, password: this.password })
      .subscribe(response => {
        localStorage.setItem('token', response.token);
        this.router.navigate(['/upload']);
      });
  }
}
