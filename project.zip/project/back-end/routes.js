const express = require('express');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, File } = require('./models');
const config = require('./config/config');
const router = express.Router();
const upload = multer({ dest: config.uploadPath });

// Middleware for authentication
const authenticate = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, config.jwtSecret, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Register user
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, password: hashedPassword });
    await user.save();
    res.sendStatus(201);
});

// Login user
router.post('/login', async (req, res) => {
    console.log(req, 'Request for Login')
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user || !await bcrypt.compare(password, user.password)) {
        return res.status(401).send('Invalid credentials');
    }
    const token = jwt.sign({ id: user._id }, config.jwtSecret);
    res.json({ token });
});

// File upload
router.post('/upload', authenticate, upload.single('file'), async (req, res) => {
    const uniqueCode = Math.floor(100000 + Math.random() * 900000).toString();
    const file = new File({
        filename: req.file.filename,
        code: uniqueCode,
        userId: req.user.id
    });
    await file.save();
    res.json({ code: uniqueCode });
});

// Get uploaded files
router.get('/files', authenticate, async (req, res) => {
    const files = await File.find({ userId: req.user.id });
    res.json(files);
});

// Delete file
router.delete('/files/:id', authenticate, async (req, res) => {
    await File.findByIdAndDelete(req.params.id);
    res.sendStatus(204);
});

// Download file
router.post('/download/:id', authenticate, async (req, res) => {
    const { code } = req.body;
    const file = await File.findById(req.params.id);
    if (file.code !== code) return res.status(403).send('Incorrect code');

    res.download(`${config.uploadPath}${file.filename}`);
});

module.exports = router;
