import { Component } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-upload',
  standalone: true,
  imports: [HttpClientModule],
  templateUrl: './upload.component.html',
  styleUrl: './upload.component.css'
})


export class UploadComponent {
  file: File | null = null;
  code: string | null = null;

  constructor(private http: HttpClient) {}

  onFileChange(event: any) {
    this.file = event.target.files[0];
  }

  uploadFile() {
    const formData = new FormData();
    if (this.file) {
      formData.append('file', this.file);
      this.http.post<{ code: string }>('http://localhost:5000/api/upload', formData, {
        headers: { Authorization: localStorage.getItem('token') || '' }
      }).subscribe(response => {
        this.code = response.code;
      });
    }
  }
}

