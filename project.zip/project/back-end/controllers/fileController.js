const File = require('../models/fileModel');
const path = require('path');
const fs = require('fs');

exports.uploadFile = async (req, res) => {
    const file = new File({
        filename: req.file.filename,
        originalname: req.file.originalname,
        userId: req.user._id
    });
    await file.save();
    res.json(file);
};

exports.getFiles = async (req, res) => {
    const files = await File.find({ userId: req.user._id });
    res.json(files);
};

exports.deleteFile = async (req, res) => {
    const file = await File.findById(req.params.id);
    if (!file && file.userId.toString() !== req.user._id.toString()) {
        return res.status(404).json({ message: 'File not found' });
    }
    fs.unlinkSync(path.join(__dirname, '../uploads', file.filename));
    await file.remove();
    res.json({ message: 'File deleted' });
};

exports.downloadFile = async (req, res) => {
    const file = await File.findById(req.params.id);
    if (!file) {
        return res.status(404).json({ message: 'File not found' });
    }
    res.download(path.join(__dirname, '../uploads', file.filename), file.originalname);
};
