import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-list',
  standalone: true,
  imports: [HttpClientModule],
  templateUrl: './file-list.component.html',
  styleUrl: './file-list.component.css'
})

export class FileListComponent implements OnInit {
  files: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadFiles();
  }

  loadFiles() {
    this.http.get<any[]>('http://localhost:5000/api/files', {
      headers: { Authorization: localStorage.getItem('token') || '' }
    }).subscribe(data => {
      this.files = data;
    });
  }

  deleteFile(id: string) {
    this.http.delete(`http://localhost:5000/api/files/${id}`, {
      headers: { Authorization: localStorage.getItem('token') || '' }
    }).subscribe(() => {
      this.loadFiles();
    });
  }

  downloadFile(id: string) {
    const code = prompt('Enter the 6-digit code:');
    if (code) {
      this.http.post(`http://localhost:5000/api/download/${id}`, { code }, {
        headers: { Authorization: localStorage.getItem('token') || '' },
        responseType: 'blob'
      }).subscribe(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'file'; // Modify as needed
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      });
    }
  }
}